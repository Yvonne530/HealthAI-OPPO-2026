package com.healthai.ankle

import android.app.Application
import android.util.Log
import com.healthai.ankle.db.RehabDatabase
import com.healthai.ankle.inference.RGMNNBridge

class RehabApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // ── Print JNI status immediately on app start ─────────────────────────
        // This is the "是否真实JNI推理" startup log required by Copilot spec.
        if (RGMNNBridge.jniAvailable) {
            Log.i("RehabApp", "✅ MNN JNI bridge loaded — REAL INFERENCE MODE (MNN ${RGMNNBridge.mnnVersion})")
        } else {
            Log.e("RehabApp", "❌ MNN JNI bridge FAILED — AI DISABLED")
            Log.e("RehabApp", "   Run: bash scripts/setup_mnn_290.sh  then rebuild")
        }

        // Warm-up DB on background thread
        Thread { RehabDatabase.getInstance(this) }.start()
    }
}
