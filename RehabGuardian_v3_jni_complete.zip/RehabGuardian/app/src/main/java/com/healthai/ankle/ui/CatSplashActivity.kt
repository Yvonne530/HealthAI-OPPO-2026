package com.healthai.ankle.ui

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.animation.OvershootInterpolator
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.healthai.ankle.R
import com.healthai.ankle.inference.RGInferenceValidator
import com.healthai.ankle.inference.RGMNNBridge
import com.healthai.ankle.inference.RGPhaseAEngine
import kotlinx.coroutines.*

/**
 * Splash screen + startup validation.
 *
 * While the cat animation plays, we:
 *   1. Init the engine on a background coroutine
 *   2. Run RGInferenceValidator to confirm real JNI inference
 *   3. Print the validation report to logcat
 *   4. Show JNI status on screen (green = real, red = disabled)
 *
 * Gap 5 & 6 are surfaced here — the user (and evaluating engineer) sees
 * the JNI status before entering the main activity.
 */
class CatSplashActivity : AppCompatActivity() {

    private lateinit var loadingTv: TextView
    private lateinit var statusTv:  TextView
    private val engine = RGPhaseAEngine()
    private val scope  = MainScope()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#FFF7ED")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#FFF7ED"))
        }

        val catView = ImageView(this).apply {
            setImageResource(R.drawable.ic_cat_mascot)
            layoutParams = LinearLayout.LayoutParams(320, 320).also {
                it.gravity = Gravity.CENTER_HORIZONTAL; it.bottomMargin = 36
            }
            scaleX = 0f; scaleY = 0f; alpha = 0f
        }

        val titleTv = TextView(this).apply {
            text = "RehabGuardian"
            textSize = 30f; setTextColor(Color.parseColor("#F97316"))
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = 8 }
            alpha = 0f
        }

        val subTv = TextView(this).apply {
            text = "踝关节康复守护猫  🐾"; textSize = 13f
            setTextColor(Color.parseColor("#C2410C")); gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = 48 }
            alpha = 0f
        }

        loadingTv = TextView(this).apply {
            text = "加载 AI 引擎…"; textSize = 12f
            setTextColor(Color.parseColor("#78716C")); gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = 8 }
            alpha = 0f
        }

        // Gap 5: JNI status line — visible to user on first launch
        statusTv = TextView(this).apply {
            text = ""; textSize = 11f; gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        root.addView(catView); root.addView(titleTv); root.addView(subTv)
        root.addView(loadingTv); root.addView(statusTv)
        setContentView(root)

        // ── Animations ────────────────────────────────────────────────────
        val catIn = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(catView, "scaleX", 0f, 1.15f, 0.95f, 1f),
                ObjectAnimator.ofFloat(catView, "scaleY", 0f, 1.15f, 0.95f, 1f),
                ObjectAnimator.ofFloat(catView, "alpha",  0f, 1f)
            )
            duration = 700; interpolator = OvershootInterpolator(1.4f)
        }
        val textIn = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(titleTv,   "alpha", 0f, 1f),
                ObjectAnimator.ofFloat(subTv,     "alpha", 0f, 1f),
                ObjectAnimator.ofFloat(loadingTv, "alpha", 0f, 1f)
            )
            duration = 500; startDelay = 350
        }
        AnimatorSet().apply { playSequentially(catIn, textIn); start() }

        // Tail-wag loop
        fun wag() {
            catView.animate().rotation(7f).setDuration(380).withEndAction {
                catView.animate().rotation(-7f).setDuration(380).withEndAction {
                    catView.animate().rotation(0f).setDuration(280).withEndAction {
                        Handler(Looper.getMainLooper()).postDelayed(::wag, 1400)
                    }.start()
                }.start()
            }.start()
        }
        Handler(Looper.getMainLooper()).postDelayed(::wag, 800)

        // ── Background: init engine + validate ────────────────────────────
        scope.launch {
            withContext(Dispatchers.IO) { engine.init(this@CatSplashActivity) }

            // Gap 5 + 6: show real JNI status
            if (RGMNNBridge.jniAvailable) {
                loadingTv.text = "MNN ${RGMNNBridge.mnnVersion} — 运行自检…"
                val report = withContext(Dispatchers.IO) {
                    RGInferenceValidator.runSync(engine)
                }
                if (report.passed) {
                    statusTv.setTextColor(Color.parseColor("#22C55E"))
                    statusTv.text = "✅ 真实推理已激活 — MNN ${RGMNNBridge.mnnVersion}"
                } else {
                    statusTv.setTextColor(Color.parseColor("#EF4444"))
                    statusTv.text = "⚠ 推理自检失败: ${report.failures.firstOrNull() ?: "unknown"}"
                }
                loadingTv.text = "风险: ${String.format("%.3f", report.riskScore)}  延迟: ${report.latencyMs}ms"
            } else {
                statusTv.setTextColor(Color.parseColor("#EF4444"))
                statusTv.text = "❌ JNI未激活 — 请运行 setup_mnn_290.sh"
                loadingTv.text = "AI已降级（仅显示界面）"
            }

            // Wait at least 2s total for animation
            delay(2000)
            startActivity(Intent(this@CatSplashActivity, RehabGuardianActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        // Engine is passed to RehabGuardianActivity via RehabApplication singleton
    }
}
