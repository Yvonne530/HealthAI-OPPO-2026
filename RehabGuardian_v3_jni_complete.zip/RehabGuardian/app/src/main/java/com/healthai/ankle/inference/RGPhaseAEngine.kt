package com.healthai.ankle.inference

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max

// ── Result ───────────────────────────────────────────────────────────────────

data class InferenceResult(
    val riskScore: Float,
    val riskLabel: Int,
    val confidence: Float,
    val jointAngles: FloatArray,
    val grfLeft: FloatArray,
    val grfRight: FloatArray,
    val grfFutureFlat: FloatArray,           // flat [10*12]
    val kneeAnglesDeg: Pair<Float, Float>,
    val explanation: RiskExplainer.Explanation,
    val motionScore: Float
) {
    val riskLabelText: String get() = when (riskLabel) {
        0 -> "低风险"; 1 -> "中风险"; else -> "高风险"
    }
    fun grfFuture2D(): Array<FloatArray> = Array(10) { t ->
        FloatArray(12) { j -> grfFutureFlat.getOrElse(t * 12 + j) { 0f } }
    }
}

// ── Engine ───────────────────────────────────────────────────────────────────

/**
 * On-device PhaseA inference engine.
 *
 * Backend: RGMNNBridge → mnn_jni.cpp → MNN 2.9.0 C++ API.
 * Backend: RGMNNBridge → mnn_jni.cpp → MNN 2.9.0 C++ API.
 *
 * Startup prints ONE of:
 *   ✅ REAL JNI INFERENCE ACTIVE     → genuine on-device inference
 *   ❌ AI DISABLED (JNI unavailable) → degraded, UI shows placeholder
 *
 * Threading:
 *   init() / release() — background thread
 *   infer()            — any thread, AtomicBoolean single-flight guard
 */
class RGPhaseAEngine {

    var userWeightKg: Float = 70f

    // JNI handles (0 = invalid / not loaded)
    private var stgcnNet:  Long = 0L
    private var stgcnSess: Long = 0L
    private var fnoNet:    Long = 0L
    private var fnoSess:   Long = 0L
    private var riskNet:   Long = 0L
    private var riskSess:  Long = 0L

    // Pre-allocated input buffers — zero per-frame heap in hot path
    private val stgcnInBuf = FloatArray(1 * 5 * 33 * 3)
    private val fnoInBuf   = FloatArray(1 * 20 * 72)
    private val riskInBuf  = FloatArray(1 * 20 * 35)

    private val inferring  = AtomicBoolean(false)
    @Volatile var lastResult: InferenceResult? = null
    private var normStats: RGNormStats? = null
    private var engineReady = false

    // ── init ─────────────────────────────────────────────────────────────

    fun init(context: Context) {
        normStats = RGNormStats(context)

        // ── Gap 5: Runtime self-check ─────────────────────────────────────
        if (!RGMNNBridge.jniAvailable) {
            Log.e(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            Log.e(TAG, "❌ AI DISABLED — JNI bridge unavailable")
            Log.e(TAG, "   Likely cause: librehab_mnn_jni.so not compiled.")
            Log.e(TAG, "   Fix: run scripts/setup_mnn_290.sh then rebuild.")
            Log.e(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            return
        }
        Log.i(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        Log.i(TAG, "✅ REAL JNI INFERENCE ACTIVE — MNN ${RGMNNBridge.mnnVersion}")
        Log.i(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        runCatching {
            val stgcnPath = copyModelPair(context, "stgcn_phaseA.mnn")
            val fnoPath   = copyModelPair(context, "fno_lstm_phaseA.mnn")
            val riskPath  = copyModelPair(context, "risk_phaseA.mnn")

            stgcnNet  = loadNet(stgcnPath,  "STGCN")
            fnoNet    = loadNet(fnoPath,    "FNO")
            riskNet   = loadNet(riskPath,   "Risk")

            // numThreads=4, forwardType=0 (CPU) — optimal for Reno15 Pro single-user
            stgcnSess = createSess(stgcnNet, "STGCN")
            fnoSess   = createSess(fnoNet,   "FNO")
            riskSess  = createSess(riskNet,  "Risk")

            // ── Gap 4: Tensor I/O shape validation ────────────────────────
            validateAllShapes()

            engineReady = true
            Log.i(TAG, "RGPhaseAEngine: all 3 models loaded and validated ✓")

        }.onFailure { e ->
            Log.e(TAG, "Model init failed — AI disabled: ${e.message}")
            releaseAll()
        }
    }

    // ── infer ─────────────────────────────────────────────────────────────

    fun infer(frames20: Array<Array<FloatArray>>): InferenceResult? {
        if (!engineReady) return lastResult
        if (!inferring.compareAndSet(false, true)) return lastResult   // single-flight

        return try {
            runPipeline(frames20)
        } catch (e: Exception) {
            Log.w(TAG, "Inference exception, using last result: ${e.message}")
            lastResult
        } finally {
            inferring.set(false)
        }
    }

    fun release() = releaseAll()

    // ── pipeline ──────────────────────────────────────────────────────────

    private fun runPipeline(frames20: Array<Array<FloatArray>>): InferenceResult {

        // §3.2  4×STGCN (5-frame chunks) → jaSeq[20][23]
        val chunks = Array(4) { FloatArray(23) }
        for (c in 0 until 4) {
            val flat = RGFeatureBuilder.sliceStgcnInput(frames20, c * 5)
            System.arraycopy(flat, 0, stgcnInBuf, 0, flat.size)

            check(RGMNNBridge.nativeSetInput(stgcnNet, stgcnSess, INPUT_VISUAL_SEQ, stgcnInBuf)) {
                "STGCN setInput failed"
            }
            check(RGMNNBridge.nativeRun(stgcnNet, stgcnSess)) { "STGCN run failed" }

            val raw = RGMNNBridge.nativeGetOutput(stgcnNet, stgcnSess, OUTPUT_JOINT_ANGLES)
                ?: throw IllegalStateException("STGCN output null")
            System.arraycopy(raw, 0, chunks[c], 0, minOf(raw.size, 23))
        }
        val jaSeq = RGFeatureBuilder.buildJaSeq(chunks)

        // §3.3  bio_seq [1,20,72]
        val bioFlat = RGFeatureBuilder.buildBioSeq(jaSeq, frames20)
        System.arraycopy(bioFlat, 0, fnoInBuf, 0, fnoInBuf.size)

        // §3.4  FNO → grf_seq [1,10,12]
        check(RGMNNBridge.nativeSetInput(fnoNet, fnoSess, INPUT_BIO_SEQ, fnoInBuf)) {
            "FNO setInput failed"
        }
        check(RGMNNBridge.nativeRun(fnoNet, fnoSess)) { "FNO run failed" }

        val fnoRaw = RGMNNBridge.nativeGetOutput(fnoNet, fnoSess, OUTPUT_GRF_SEQ)
            ?: throw IllegalStateException("FNO output null")
        val grf0         = fnoRaw.copyOfRange(0, minOf(12, fnoRaw.size))
        val grfFutureAll = fnoRaw.copyOf()

        // §3.5  risk_seq [1,20,35]
        val riskFlat = RGFeatureBuilder.buildRiskSeq(jaSeq, grf0, normStats!!)
        System.arraycopy(riskFlat, 0, riskInBuf, 0, riskInBuf.size)

        // §3.6  Risk → logits [3] + confidence [1]
        check(RGMNNBridge.nativeSetInput(riskNet, riskSess, INPUT_RISK_SEQ, riskInBuf)) {
            "Risk setInput failed"
        }
        check(RGMNNBridge.nativeRun(riskNet, riskSess)) { "Risk run failed" }

        val logitsRaw = RGMNNBridge.nativeGetOutput(riskNet, riskSess, OUTPUT_RISK_LOGITS)
            ?: throw IllegalStateException("Risk logits null")
        val confRaw   = RGMNNBridge.nativeGetOutput(riskNet, riskSess, OUTPUT_RISK_CONF)
            ?: FloatArray(1)

        val logits     = logitsRaw.copyOfRange(0, minOf(3, logitsRaw.size))
        val probs      = softmax(logits)
        val riskScore  = probs.getOrElse(2) { 0f }
        val riskLabel  = probs.indices.maxByOrNull { probs[it] } ?: 0
        val confidence = confRaw.getOrElse(0) { probs.max() }.let { if (it.isFinite()) it else probs.max() }

        val finalJa  = jaSeq[19].copyOf()
        val grfLeft  = normStats!!.denormGrfLeft(grf0.copyOfRange(0, minOf(6, grf0.size)))
        val grfRight = normStats!!.denormGrfRight(grf0.copyOfRange(minOf(6, grf0.size), minOf(12, grf0.size)))
        val lKnee    = finalJa.getOrElse(RGMarkerMapper.JA_L_KNEE) { 0f } * RAD_TO_DEG
        val rKnee    = finalJa.getOrElse(RGMarkerMapper.JA_R_KNEE) { 0f } * RAD_TO_DEG
        val motScore = computeMotionScore(lKnee, rKnee, grfLeft, grfRight)

        val explanation = RiskExplainer.explain(
            lKnee, rKnee, grfLeft, grfRight, grfFutureAll, riskScore, motScore
        )

        return InferenceResult(
            riskScore      = riskScore,
            riskLabel      = riskLabel,
            confidence     = confidence,
            jointAngles    = finalJa,
            grfLeft        = grfLeft,
            grfRight       = grfRight,
            grfFutureFlat  = grfFutureAll,
            kneeAnglesDeg  = lKnee to rKnee,
            explanation    = explanation,
            motionScore    = motScore
        ).also { lastResult = it }
    }

    // ── Gap 4: Shape validation ───────────────────────────────────────────

    private fun validateAllShapes() {
        // STGCN
        RGMNNBridge.validateShape(stgcnNet, stgcnSess, INPUT_VISUAL_SEQ,    true,  intArrayOf(1, 5, 33, 3))
        RGMNNBridge.validateShape(stgcnNet, stgcnSess, OUTPUT_JOINT_ANGLES, false, intArrayOf(1, 23))
        // FNO
        RGMNNBridge.validateShape(fnoNet,   fnoSess,   INPUT_BIO_SEQ,       true,  intArrayOf(1, 20, 72))
        RGMNNBridge.validateShape(fnoNet,   fnoSess,   OUTPUT_GRF_SEQ,      false, intArrayOf(1, 10, 12))
        // Risk
        RGMNNBridge.validateShape(riskNet,  riskSess,  INPUT_RISK_SEQ,      true,  intArrayOf(1, 20, 35))
        RGMNNBridge.validateShape(riskNet,  riskSess,  OUTPUT_RISK_LOGITS,  false, intArrayOf(1, 3))
        RGMNNBridge.validateShape(riskNet,  riskSess,  OUTPUT_RISK_CONF,    false, intArrayOf(1, 1))
    }

    // ── helpers ───────────────────────────────────────────────────────────

    private fun loadNet(path: String, tag: String): Long {
        val h = RGMNNBridge.nativeCreateNet(path)
        check(h != 0L) { "$tag: createNet failed for $path" }
        Log.i(TAG, "$tag net loaded: handle=$h")
        return h
    }

    private fun createSess(netHandle: Long, tag: String): Long {
        val h = RGMNNBridge.nativeCreateSession(netHandle, 4, 0)
        check(h != 0L) { "$tag: createSession failed" }
        return h
    }

    private fun softmax(logits: FloatArray): FloatArray {
        val mx = logits.max()
        val e  = FloatArray(logits.size) { i -> exp((logits[i] - mx).toDouble()).toFloat() }
        val s  = e.sum()
        return FloatArray(e.size) { i -> e[i] / s }
    }

    private fun computeMotionScore(lK: Float, rK: Float, grfL: FloatArray, grfR: FloatArray): Float {
        val sym    = (1f - minOf(abs(lK - rK) / 40f, 1f)) * 100f
        val flex   = (minOf(lK, rK) / 180f).coerceIn(0f, 1f) * 100f
        val impact = max(abs(grfL.getOrElse(0) { 0f }), abs(grfR.getOrElse(0) { 0f }))
        val imp    = (1f - minOf(impact / 3f, 1f)) * 100f
        return (sym * 0.30f + flex * 0.50f + imp * 0.20f).coerceIn(0f, 100f)
    }

    private fun copyModelPair(context: Context, fileName: String): String {
        val dir = File(context.cacheDir, "mnn_models").also { it.mkdirs() }
        copyAsset(context, "models/$fileName",        File(dir, fileName))
        copyAsset(context, "models/$fileName.weight", File(dir, "$fileName.weight"))
        return File(dir, fileName).absolutePath
    }

    private fun copyAsset(ctx: Context, asset: String, dest: File) {
        if (dest.exists() && dest.length() > 0) return
        runCatching {
            ctx.assets.open(asset).use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
        }.onFailure { Log.w(TAG, "Asset copy failed: $asset — ${it.message}") }
    }

    private fun releaseAll() {
        runCatching { if (stgcnNet != 0L && stgcnSess != 0L) RGMNNBridge.nativeReleaseSession(stgcnNet, stgcnSess) }
        runCatching { if (fnoNet   != 0L && fnoSess   != 0L) RGMNNBridge.nativeReleaseSession(fnoNet,   fnoSess)   }
        runCatching { if (riskNet  != 0L && riskSess  != 0L) RGMNNBridge.nativeReleaseSession(riskNet,  riskSess)  }
        runCatching { if (stgcnNet != 0L) RGMNNBridge.nativeReleaseNet(stgcnNet) }
        runCatching { if (fnoNet   != 0L) RGMNNBridge.nativeReleaseNet(fnoNet)   }
        runCatching { if (riskNet  != 0L) RGMNNBridge.nativeReleaseNet(riskNet)  }
        stgcnNet = 0L; stgcnSess = 0L
        fnoNet   = 0L; fnoSess   = 0L
        riskNet  = 0L; riskSess  = 0L
        engineReady = false
        Log.i(TAG, "RGPhaseAEngine released")
    }

    companion object {
        private const val TAG                 = "RGPhaseAEngine"
        private const val INPUT_VISUAL_SEQ    = "visual_seq"
        private const val OUTPUT_JOINT_ANGLES = "joint_angles"
        private const val INPUT_BIO_SEQ       = "bio_seq"
        private const val OUTPUT_GRF_SEQ      = "grf_seq"
        private const val INPUT_RISK_SEQ      = "risk_seq"
        private const val OUTPUT_RISK_LOGITS  = "risk_logits"
        private const val OUTPUT_RISK_CONF    = "risk_confidence"
        private const val RAD_TO_DEG          = 180f / Math.PI.toFloat()
    }
}
